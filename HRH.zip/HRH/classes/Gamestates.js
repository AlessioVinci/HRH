"use strict";
var HRH;
(function (HRH) {
    let Gamestates;
    (function (Gamestates) {
        Gamestates[Gamestates["EDIT"] = 0] = "EDIT";
        Gamestates[Gamestates["PLAY"] = 1] = "PLAY";
    })(Gamestates = HRH.Gamestates || (HRH.Gamestates = {}));
})(HRH || (HRH = {}));
//# sourceMappingURL=Gamestates.js.map