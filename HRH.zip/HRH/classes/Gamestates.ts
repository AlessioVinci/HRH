namespace HRH {
  export enum Gamestates {
    EDIT,
    PLAY
  }
}