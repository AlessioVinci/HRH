namespace HRH {
  export enum MovementDirections {
    UP,
    LEFT,
    DOWN,
    RIGHT,
    NONE
  }
}